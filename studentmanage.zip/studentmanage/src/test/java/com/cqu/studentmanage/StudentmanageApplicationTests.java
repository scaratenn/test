package com.cqu.studentmanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmanageApplicationTests {

    @Test
    void contextLoads() {
    }

}
