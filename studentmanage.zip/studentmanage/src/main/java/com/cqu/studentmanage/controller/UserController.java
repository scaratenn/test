package com.cqu.studentmanage.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cqu.studentmanage.hanshu.UserRegiter;
import com.cqu.studentmanage.mapper.UserMapper;
import com.cqu.studentmanage.pojo.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.sql.Wrapper;
import java.util.Objects;

@Slf4j
@RestController
public class UserController {
    @Resource
    private UserMapper userMapper;

    @GetMapping("/login")
    public String  login(@RequestParam Integer id,@RequestParam String password){
        User o=userMapper.selectOne(Wrappers.<User>lambdaQuery().eq(User::getId,id));
        if(o==null){
            return "cant find user";
        }
        if(!o.getPassword().equals(password)){
            return "password false";
        }
        log.info("username:{},password:{}",id,password);
        log.info("o:{}",o);
        return " login success";
    }
    @GetMapping("/register")
    public boolean register(@RequestBody UserRegiter userRegiter){
        Integer id= Integer.valueOf(userRegiter.getId());
        String password= String.valueOf(userRegiter.getPassword());
        User user = userMapper.selectOne(Wrappers.<User>lambdaQuery()
                .eq(User::getId,id));
        if (Objects.nonNull(user)){
            return false;
        }
        User newUser = new User();
        newUser.setId(id);
        newUser.setPassword(password);
        userMapper.insert(newUser);
        return true;
    }

}
