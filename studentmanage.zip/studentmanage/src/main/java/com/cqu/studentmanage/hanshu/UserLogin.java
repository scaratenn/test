package com.cqu.studentmanage.hanshu;

import com.mysql.cj.x.protobuf.MysqlxDatatypes;
import lombok.Data;

@Data
public class UserLogin {
    private Integer id;
    private MysqlxDatatypes.Scalar.String password;
}

