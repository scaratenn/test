package com.cqu.studentmanage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cqu.studentmanage.pojo.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends BaseMapper<User> {
}
